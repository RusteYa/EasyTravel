create function fib(num integer, OUT result integer) returns integer
LANGUAGE plpgsql
AS $$
BEGIN
  IF num > 2
  THEN result := fib(num - 1) + fib(num - 2);
    ELSE result := 1;
  END IF;
END
$$;
