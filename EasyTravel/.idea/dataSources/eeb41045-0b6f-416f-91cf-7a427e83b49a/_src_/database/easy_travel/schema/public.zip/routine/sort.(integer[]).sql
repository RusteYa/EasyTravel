create function sort(arr integer[], OUT result integer[]) returns integer[]
LANGUAGE plpgsql
AS $$
DECLARE a INTEGER;
BEGIN
  FOR i IN 1..(array_length(arr, 1) - 1) LOOP
    FOR j IN REVERSE i..2 LOOP
      IF (arr [j] < arr [j - 1])
      THEN
        a := arr [j];
        arr [j] := arr [j - 1];
        arr [j - 1] := a;
      END IF;
    END LOOP;
  END LOOP;
  result := arr;
END
$$;
