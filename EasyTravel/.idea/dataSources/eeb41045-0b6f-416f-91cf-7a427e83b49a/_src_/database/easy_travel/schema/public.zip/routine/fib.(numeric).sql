create function fib(num numeric) returns numeric
LANGUAGE plpgsql
AS $$
BEGIN
  IF num = 0
  THEN RETURN 0;
  END IF;
  IF num = 1
  THEN RETURN 1;
  END IF;
  IF num = 0
  THEN RETURN (fib(num - 1) + fib(num - 2));
  END IF;
END
$$;
