CREATE VIEW messages_count_per_month AS SELECT date_part('month'::text, message.date) AS month,
    count(message.id) AS message_count
   FROM message
  GROUP BY (date_part('month'::text, message.date));
