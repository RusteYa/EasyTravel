create function denorm_users_fill() returns void
LANGUAGE plpgsql
AS $$
BEGIN
  INSERT INTO denorm_users (id, login, hashed_password, salt, email, token, name, surname, fathers_name, photo_path, user_data_file)
    SELECT
      users.id AS id,
      login,
      hashed_password,
      salt,
      email,
      token,
      name,
      surname,
      fathers_name,
      photo_path,
      user_data_file
    FROM users
      JOIN login_data ON users.login_data_id = login_data.id
      JOIN profile ON users.profile_id = profile.id;
END;
$$;
